# Nubank Design System

A design + brand system for **Nubank** (Nu) — the global digital bank. This project packages the **2026 Nubank Global Brand Guidelines** as a working toolkit: tokens, typography, logos, voice, and a UI kit, so a design agent can produce on-brand artifacts (mocks, slides, prototypes, marketing pages, app screens) without re-deriving the system every time.

> **Sources used**
> - `uploads/Global I Nubank Brand Guidelines2.pdf` — the official 2026 Global Brand Guidelines book (221 pages, CONFIDENTIAL). Raw extracted text is preserved in `research/brand-guidelines-raw.txt`.
> - Logo PNG suite (purple / UV purple / white / black variants, container + cutout marks for UV print and digital).
> - Full **Nu Sans** font family: `Display` (Light → Semibold, Neutral / Cnd / Ext widths) and `Text` (Regular → Bold). OTFs live in `fonts/`.
>
> No Figma file or codebase was attached — UI kits are visual reconstructions following the brand book.

---

## Brand strategy at a glance

| | |
| --- | --- |
| **Purpose** | Fight Complexity to Empower People. |
| **Ambition (BHAG)** | Reinvent services to liberate 1 billion fanatical customers from complexity in their daily lives. |
| **Positioning** | Effortless banking, designed to delight. |
| **Brand Persona** | The Possibility Maker — an inventive financial ally. Archetype: **Creator**. Energy: curiosity, optimism, creation. |
| **Attributes** | Magically Useful · Easy to Trust · Relentlessly Efficient · Future Shaper · Surprisingly Unbiased |
| **Expression Principles** | **Bold Transparency** · **Human Warmth** · **Effortlessly Structured** |

These three Expression Principles are the through-line of every decision in this system. Anything we make should be (a) transparent and impossible to ignore, (b) warm and human, and (c) calm, intentionally simple.

---

## Repo index

```
.
├── README.md                  ← you are here
├── SKILL.md                   ← Agent Skills entry point (cross-compatible)
├── colors_and_type.css        ← All CSS variables (color, type, space, motion)
├── fonts/                     ← Nu Sans OTFs (Display, Display Cnd/Ext, Text)
├── assets/                    ← Logos (purple/uv/white/black, container + cutout)
├── research/                  ← Raw extracted text from the brand book PDF
├── preview/                   ← Cards that populate the Design System tab
│   ├── colors-*.html
│   ├── type-*.html
│   ├── space-*.html
│   ├── components-*.html
│   └── brand-*.html
└── ui_kits/
    ├── nu-app/                ← Mobile app UI kit (React/JSX click-thru)
    └── nu-web/                ← Marketing site UI kit
```

To use the system, link `colors_and_type.css` and pull tokens via `var(--core-purple)`, `var(--font-display)`, etc.

---

## Content fundamentals

> *"How we speak shows who we are."* — Verbal Identity, p. 34

Verbal voice is governed by three principles. They're **a floor, not a ceiling**: every piece of copy should pass all three.

### 1. Keep It Real
We don't hide behind jargon. We say what matters with confidence, so people always know where they stand.
- Use plain, everyday words and active voice ("We'll refund you today.").
- Name the hard stuff upfront — fees, limits, rules — headline it, don't footnote it.
- Default to **"you"** over "users". Always write to one person.
- Don't sound combative or performative "no-BS". Don't use jargon as tone ("may be eligible to potentially…").

✅ "Hidden fees? Not here." · "When it's your money, you deserve to know everything."
❌ "We are continuously striving to enhance your holistic financial experience."

### 2. Speak With Heart
We talk like a person who's on your side. Grounded in real life, we bring energy to every interaction.
- Celebrate progress in human terms ("Goal hit. Trip booked.").
- Use language that invites — "lets…", "here's how…" — over "you must".
- Don't slip into cliché or cheerleading. Don't use insider slang ("hey bestie!"). Don't make empathy performative.

✅ "Your transfer's in. We'll confirm the moment it clears." · "You did the hard part. We'll handle the rest."
❌ "You're on your way to your financial glow-up." · "Live, laugh, bank."

### 3. Make It Clear
We make complex things easy to understand. Our language creates calm and gives people the guidance to act.
- One idea per sentence; aim for **under 15 words**.
- Lead with calm and clarity over cleverness; simple doesn't mean boring.
- Don't over-explain or drown people in caveats. Don't sound robotic or stripped of humanity.

✅ "Money moves instantly, because waiting isn't banking." · "Your limit increased. It's live now."
❌ "If your payment exceeds pre-approval limits, see exception 3B for eligibility."

### Sad paths (errors, failed transactions)
Be **direct, honest, concrete**. Say what happened, show support, give next steps as a scannable list. Use active voice ("we couldn't process…") and real nouns ("expired", "paused", "declined"). Avoid: "Account locked. Too many login attempts." Prefer: "We know this is frustrating, here's how to fix it fast."

### Emojis
Used **sparingly** and only when they support the message. Stick to universally understood symbols (✅ 🔒 💜). One emoji per message, placed at the end of a sentence — never replacing a word. Acceptable in social and less-formal comms; rare in functional UX.

### Slang & contemporary expressions
Speak to culture, not chase it. Conversational, natural — no memes, no regional slang, no idioms ("in the pipeline"), nothing that won't translate globally. "We've got you covered," not "we gotchu fam."

### Wordmark & naming
- The brand name in copy is **"Nubank"** — Title Case, set in **Nu Sans Display**, no extra letter spacing.
- Sub-brands prefix with **"Nu"** in all languages **except Spanish**, where it's a suffix (e.g. *Cuenta Nu*).
- Four naming formats: `Nu + Descriptive` (NuPay), `Nu + Associative` (Nu Empresas), `Descriptive` (Buscador de Boletos), `Associative` (Cajitas).

---

## Visual foundations

### Color

The system is anchored on a single signature color: **Core Nu Purple `#8D0DE3`**. Everything else in the palette exists to make purple sing — to give it warmth (Sand), depth (UV Purple), or breathing room (white).

**Primary palette** (use these by default)

| Role | Name | Hex |
| --- | --- | --- |
| Signature | **Core Purple** | `#8D0DE3` |
| Premium / dark | **UV Purple** | `#1E002F` |
| Warm background (replaces pure white) | **Sand** | `#F3EFE6` |
| Soft tint | **Purple 100** | `#ECDFFF` |
| Mid tint | **Purple 300** | `#CBA5FD` |
| | White | `#FFFFFF` |
| | Pure Black | `#000000` |

**Secondary palette** — energy and warmth; never use for typography on photography, never use as full-bleeds that compete with Core Purple.

| Light Blue `#8DCDE2` · Blue `#96B0FD` · Tan `#E5D8BD` · Yellow `#EEEDB3` · Pink `#DA9AC7` · Green `#A7D296` · Rose Gold `#E9A6A7` · Teal `#85D1BD` |
| --- |

**Color proportions** (default volume balance, p. 83): Core Purple 30% · Secondary 20% · Sand 15% · Purple 100 10% · Purple 300 10% · White 5% · UV Purple 5% · Black 5%. "Strict purple" applies to OOH, app tiles, exterior marketing. "Flexible palette" applies to in-app, social, events.

**Type-on-color rule** (p. 95): **Core Purple is the default typography color on every background — except on Core Purple itself or Brown.** On Core Purple and UV Purple use Sand or White.

**Don'ts**
- ❌ No gradients. Anywhere. Ever.
- ❌ No new colors introduced into the system.
- ❌ Don't use the extended palette on main brand assets.
- ❌ Don't use secondary colors for typography, especially over photography.
- ❌ Don't full-bleed UV Purple (it's Ultravioleta's territory — reserve for subtle accents).

### Typography

Two families: **Nu Sans Display** (headlines, expressive moments) and **Nu Sans Text** (body, UI, dense reading). Use the **Neutral width only** by default; Condensed and Extended are reserved for special expressive moments and need brand-team sign-off.

| Role | Family / Weight | Tracking | Line-height |
| --- | --- | --- | --- |
| Headline (H1) | **Nu Sans Display Semibold** | **−3%** | **90%** |
| Sub Headline (H2) | **Nu Sans Display Medium** | **−2%** | **100%** |
| Paragraph (P) | **Nu Sans Text Regular** | 0% | 120% |
| Button (B) | **Nu Sans Text Semibold** | 0% | 100% |
| Annotation (A) | **Nu Sans Text Medium** | 0% | 100% |

**Don'ts**
- ❌ Don't shout in all caps or uppercase.
- ❌ Don't track type too wide.
- ❌ Don't use italics in headlines.
- ❌ Don't mix multiple font styles in a single word.
- ❌ Don't set long blocks in Extended width.
- ❌ Don't distort or recreate font variations.

### Logo

The logomark is the lowercase **"nu"** in a **purple square container** — the preferred version, used by default. The container amplifies Core Purple's presence; the no-container mark is for grayscale, signage, or sub-brand lockups.

**Two color treatments only**: Core Nu Purple and White. Use **Purple logo** on light/neutral backgrounds and non-purple imagery. Use **White logo** on purple backgrounds and purple-heavy imagery.

**Safe area** = the height of the "nu". **Don'ts**: no stretch, no new colors, no resized symbol, no purple logo on purple-heavy art, no gradients, no strokes.

### Layout

- **Margins**: longest side of the canvas ÷ **28**. Adjust manually for extreme aspect ratios.
- **Grids**: 12-column base, with 2 / 4 / 6 / 8-column variants for different surfaces (all multiples of 12). Gutter = margin ÷ 2 or ÷ 4.
- Three **activation principles** dictate composition:
  - **Nu as the Source** — benefits radiate outward from the logo / center. Bold, expressive, campaign-grade.
  - **Nu as the Connector** — logo acts as a magnet between images / type / elements. Playful but calmer.
  - **Nu as the Structure** — editorial grid layouts, more restrained. Used primarily for **Ultravioleta** and web-app contexts.
- **Layout don'ts**: don't bleed off two opposing edges; don't overload; don't break messaging unnecessarily; don't repeat imagery within a frame.

### Buttons (p. 134)

Buttons are **pill-shaped** (or fully circular for icon/arrow buttons). The text is centered with a **semicircle-of-button-height** margin on each side.
- **Button + arrow**: separate type and arrow by ¼ of the button's diameter. Arrow size matches the matching arrow glyph in Nu Sans.
- **Button + inset icon**: icon height = 2× font height.
- **Arrow / icon button** (circular): icon ≈ **40%** of the button diameter, optically centered.
- In conversion layouts, button height = **½ the height of the logo**, aligned to layout margins.

### Photography & art direction

Three principles: **Human and Authentic** · **In the Moment** · **Playful and Alive**.

- **Light**: warm, natural, human. Daylit or sun-warmed. Avoid harsh artificial sources; avoid cold sterile feeling. Even when cool tones appear, contrast must carry warmth.
- **Perspective**: close-up, first-person, intimate. Use background blur, foreground motion, natural occlusion.
- **Movement & texture**: motion blur, skin, fabric, sunlight, imperfection. Embrace tactile realism, never polish.
- **Grading recipe**: desaturated yellows/oranges · saturated greens/aquas/blues · slightly cooler overall temperature · higher vibrancy · subtle purple highlight.
- **Purple in imagery**: as **highlight** (one pop, foreground), as **thread** (across a set), as **energy** (lighting/grading cues), or as **proportion** (dialed up or down by context). Match purple's vibrancy to the rest of the frame's saturation.

### Illustration

Two roles only:
- **Hero illustrations** — full-bleed, immersive, emotional. For editorial, campaigns, celebratory moments.
- **Spot illustrations** — centered on white/neutral/sand, silhouetted. For onboarding, walkthroughs, alerts, success screens, notification cards.

**Shape rule**: geometric construction for objects (phones, cards, buildings, lamps); organic forms for people and nature. The contrast between geometric and organic is the brand's signature illustration tension.

**Don'ts**: no hairline strokes, no painted textures, no overly rounded/elongated limbs, no childish/allegorical scenes, no over-detail.

### Motion (p. 196)

Three principles: **Bold · Clarity · Fluid.**

- **Easing**: up to **90% in / 90% out** — strong, dynamic, "slick". Movement should feel like momentum, never weighty or springy.
- **No bounce, no overshoot, no decorative tricks.**
- **Rotation**: shapes can rotate; **content (type, imagery) stays straight to the camera**.
- The three layout activations map directly to motion variants:
  - *Nu as the Source* → motion flows outward.
  - *Nu as the Connector* → elements move in relation to each other.
  - *Nu as the Structure* → motion reinforces grid + alignment.

### Sonic signature

Brand has a sonic logo derived from the **D♭ major scale** ("the harmonic scale of purple"). Motif: **A♭ → D♭ → A♭ → F** — a 4-tone, call-and-response figure.
- **Under 6s asset** → no sonic signature.
- **6–15s** → sonic signature optional but preferred.
- **Over 15s** → sonic signature mandatory.

(Not directly applicable to static HTML deliverables, but flagged for video/animation work.)

### Cards, surfaces, elevation

The product UI sits on **Sand** (`#F3EFE6`) — warmer than pure white. Cards on Sand are **white** with **rounded corners** (16px) and the **softest possible shadow**. Product widgets shown on photography use a subtle **glass effect** (white 85% opacity, frost 10, depth 30) per p. 168.

### Transparency & blur

Used only on **product widgets over photography** (glass effect described above) and on sheet scrims. Not a general UI texture.

### Product widgets (home-screen / dashboard)

The *Widget Templates* Figma defines a three-size widget system that sits on photography with a **frosted-glass** fill (`rgba(255,255,255,0.85)` + `backdrop-filter: blur(24px)`). Recreated faithfully in `preview/components-widget-*.html`:

- **Small** — a pill (height ~60px, fully rounded): icon circle + bold copy, optionally a value or a coloured ↑/↓ delta.
- **Medium** — a ~28px-radius card: a primary value with delta, a copy + secondary line, or a transaction **notification** (app-icon + merchant + amount + time).
- **Large** — a ~30px-radius card: value + progress bar + illustration, or value + delta + a pill **button**; can also frame a mini app-screen.

Building blocks (all in `preview/components-widget-blocks.html`): the **icon** (50px Core-Purple or UV circle), the **app icon** (`nu` container mark, 12px-radius square), the **primary value** (Nu Sans Display 30px, `#1F0230`), the **delta** (green `#0C7A3A` ↑ / red `#D01D1C` ↓), the **button** (purple or UV pill), and the **spot illustration** (geometric beads + check, the brand's geometric-object style).

---

## Iconography

Nubank uses a custom in-house outlined icon library. A subset of the **real Nu icons** is now in this system, extracted from the *Widget Templates* Figma file and saved as SVGs in `assets/icons/`:

`globe` · `receipt` · `money-in` · `money-out` · `money-box` · `pig` · `pix` · `rewards` · `chat`

These are single-path SVGs using `fill="currentColor"`, so they recolor cleanly. Two ways to use them:

```html
<!-- as an image (inherits its own dark fill; dim with opacity) -->
<img src="assets/icons/pix.svg" width="24" alt="">

<!-- recolored via CSS mask -->
<span style="width:24px;height:24px;background:var(--core-purple);
  -webkit-mask:url(assets/icons/pix.svg) center/contain no-repeat;
  mask:url(assets/icons/pix.svg) center/contain no-repeat;"></span>
```

In the widget system the standard treatment is a **50px Core-Purple circle** with a **32px dark glyph** (`rgba(0,0,0,0.64)`) centred inside.

> ⚠️ **Partial set.** Only the single-path glyphs flattened cleanly out of Figma. Composite icons (card, bell, headset, calendar, check, etc.) are built from nested vectors and did NOT export as standalone SVGs. For anything not in `assets/icons/`, substitute **[Lucide Icons](https://lucide.dev)** (CDN, same 24×24 grid / 2px stroke / rounded joins) and flag the substitution — or ask for the full production `Nu Icon` library.

**Usage rules**
- **Color**: icons inherit `currentColor`. They are **Core Purple** for accents and feature highlights, **`--fg-1`** for body, **white** on purple surfaces.
- **Sizes**: 16 (dense lists), 20 (default), 24 (feature), 32–48 (hero / empty states).
- **No emoji as UI furniture.** Emoji belong inside chat / informal copy only, per voice rules above. Never use ✓ ✗ → as substitutes for icons.

### Logo & brand asset inventory (`assets/`)

| File | What it is | Use it for |
| --- | --- | --- |
| `logo-purple.png` | "nu" mark, Core Purple, no container | Light/neutral backgrounds |
| `logo-white.png` | "nu" mark, white, no container | Purple/dark backgrounds |
| `logo-black.png` | "nu" mark, black | Grayscale, signage |
| `container-purple.png` | "nu" in purple square — **preferred lockup** | Default brand mark |
| `container-white.png` | "nu" in white square | Inverted contexts |
| `container-cutout-purple.png` | Purple square with the "nu" cut out | Stickers, large-scale brand windows |
| `container-cutout-white.png` | White square with "nu" cut out | Inverted cutout |
| `container-dp-purple-uv.png` | "nu" in UV Purple container | UV / premium / Ultravioleta hints |
| `container-cutout-dp-purple-uv.png` | UV Purple cutout | UV print, foil applications |
| `container-white-uv.png` | White-on-UV container | Print, UV varnish overlays |
| `logo-on-purple.png` | White logomark sitting on Core Purple bg | Hero brand surfaces |
| `logo-on-dp-purple.png` | White logomark on UV Purple bg | Ultravioleta moments |
| `logo-on-black.png` | White logomark on black | Grayscale brand surface |

---

## Caveats & open questions

1. **The brand book references icon sets, sonic assets, illustration kits, and 3D card renders that are not in the package.** I've substituted Lucide for icons and noted illustrations / renders as TODO. Please share any of the following if available:
   - Nubank's production icon library (Figma or SVG)
   - Hero / Spot illustration master files
   - 3D card renders (Mastercard / Ultravioleta / NuPay)
   - The actual sonic logo audio file
2. **No Figma file or codebase** was attached. UI kits are visual reconstructions based on (a) the brand book's component examples (buttons, widgets, layout) and (b) publicly-known Nu product surfaces. If you have access to the Figma source for the app + marketing site, sharing it would let me lock down spacing, motion timings, and component variants to the real numbers.
3. The brand book's **extended palette** (10-stop ramps for grey, red, pink, purple, blue, light blue, teal, green, lime, yellow, amber, orange) is named but the exact hex values aren't listed for every stop in the extracted text. I've derived the **grey** and **purple** ramps to anchor on the stated endpoints (Core Purple = 600, UV Purple = 1000, Purple 100 / 300 as given). Other ramps (red/green/amber/blue) are sensible product-UI defaults; **please confirm or replace** with the official values.
4. **Typography color don't** rules say "Core Purple is the default typography color on every background except on Core Purple itself or Brown." I haven't seen Brown defined in the primary or secondary palettes — possibly an extended palette name. Flagged.
